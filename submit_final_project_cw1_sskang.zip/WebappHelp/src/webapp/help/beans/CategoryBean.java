package webapp.help.beans;

import webapp.help.utility.*; 

public class CategoryBean {
	Category category;
	
	public CategoryBean(Category category){
		this.category = category;
	}
}
