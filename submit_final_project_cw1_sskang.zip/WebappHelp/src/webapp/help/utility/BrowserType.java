package webapp.help.utility;

public enum BrowserType {
	Mobile,
	Desktop
}
