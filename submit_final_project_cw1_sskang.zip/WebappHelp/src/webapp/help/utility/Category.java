package webapp.help.utility;

public class Category {
	// entity can't have enum types as parameters
	// so switched to string
	public static String GENERAL = "GENERAL";
	public static String MEDICAL = "MEDICAL";
	public static String CAR = "CAR";
	public static String FIRE ="FIRE";
}
