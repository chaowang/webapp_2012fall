﻿var configuration = 
{
"showPageNotes":true,
"loadFeedbackPlugin":false}