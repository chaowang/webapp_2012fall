﻿var sitemap = 
{
"rootNodes":[
{
"pageName":"Home",
"type":"Wireframe",
"url":"Home.html"},
{
"pageName":"edit",
"type":"Wireframe",
"url":"edit.html"},
{
"pageName":"add",
"type":"Wireframe",
"url":"add.html"}]};
